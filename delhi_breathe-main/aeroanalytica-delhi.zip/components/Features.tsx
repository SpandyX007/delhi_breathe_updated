
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Database, Eraser, FunctionSquare, Clock, Layers, Cpu, Target,
  X, ZoomIn, ZoomOut, Maximize, Minimize, Save, Trash2, Undo2, Redo2, Grip
} from 'lucide-react';
import { fetchPipelinePlan } from '../services/api'; // UPDATED IMPORT
import { Node, Edge, NodeType, PipelineSchema } from '../types';
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- VISUAL CONTRACT (Section VIII.A) ---

const NODE_VISUALS: Record<NodeType, { color: string, icon: React.ReactNode, border: string, bg: string }> = {
  source: { 
    color: 'text-blue-500', 
    icon: <Database size={16} />, 
    border: 'border-blue-500/50', 
    bg: 'bg-blue-500/10' 
  },
  cleaning: { 
    color: 'text-teal-500', 
    icon: <Eraser size={16} />, 
    border: 'border-teal-500/50', 
    bg: 'bg-teal-500/10' 
  },
  transform: { 
    color: 'text-amber-500', 
    icon: <FunctionSquare size={16} />, 
    border: 'border-amber-500/50', 
    bg: 'bg-amber-500/10' 
  },
  temporal: { 
    color: 'text-orange-500', 
    icon: <Clock size={16} />, 
    border: 'border-orange-500/50', 
    bg: 'bg-orange-500/10' 
  },
  aggregation: { 
    color: 'text-purple-500', 
    icon: <Layers size={16} />, 
    border: 'border-purple-500/50', 
    bg: 'bg-purple-500/10' 
  },
  model: { 
    color: 'text-violet-500', 
    icon: <Cpu size={16} />, 
    border: 'border-violet-500/50', 
    bg: 'bg-violet-500/10' 
  },
  output: { 
    color: 'text-green-500', 
    icon: <Target size={16} />, 
    border: 'border-green-500/50', 
    bg: 'bg-green-500/10' 
  },
};

// Initial Mock Data compliant with Schema
const RAW_NODES: Node[] = [
  { 
    id: 'raw_wind', 
    type: 'source', 
    label: 'Wind Sensor Array', 
    description: 'Telemetry from 4 major stations', 
    position: { x: 100, y: 100 }, 
    connect_from: [],
    config: { source_name: 'Sensor_Array_A', format: 'api', refresh_rate: 'realtime' } 
  },
  { 
    id: 'raw_temp', 
    type: 'source', 
    label: 'IMD Temperature', 
    description: 'Ambient temp data', 
    position: { x: 100, y: 240 }, 
    connect_from: [],
    config: { source_name: 'IMD_Station', format: 'database', refresh_rate: 'hourly' } 
  },
  { 
    id: 'raw_sat', 
    type: 'source', 
    label: 'Sentinel-5P AOD', 
    description: 'Satellite Aerosol Optical Depth', 
    position: { x: 100, y: 380 }, 
    connect_from: [],
    config: { source_name: 'Sentinel-5P', format: 'satellite', refresh_rate: 'daily' } 
  },
];

interface Viewport {
  x: number;
  y: number;
  zoom: number;
}

interface HistoryState {
  nodes: Node[];
  edges: Edge[];
}

interface FeaturesProps {
  pendingPrompt: string | null;
  onClearPrompt: () => void;
  onLog: (message: string) => void;
  onProgress: (percent: number) => void;
  isFullScreen?: boolean;
  onToggleFullScreen?: () => void;
}

export const Features: React.FC<FeaturesProps> = ({ 
  pendingPrompt, 
  onClearPrompt, 
  onLog, 
  onProgress,
  isFullScreen,
  onToggleFullScreen
}) => {
  // Canvas State with Persistence
  const [nodes, setNodes] = useState<Node[]>(() => {
    const saved = localStorage.getItem('aero_features_nodes_v2');
    return saved ? JSON.parse(saved) : RAW_NODES;
  });
  const [edges, setEdges] = useState<Edge[]>(() => {
    const saved = localStorage.getItem('aero_features_edges_v2');
    return saved ? JSON.parse(saved) : [];
  });
  const [viewport, setViewport] = useState<Viewport>({ x: 0, y: 0, zoom: 1 });
  
  // History Stack
  const [history, setHistory] = useState<HistoryState[]>([{ nodes: RAW_NODES, edges: [] }]);
  const [historyIndex, setHistoryIndex] = useState(0);

  // Interaction State
  const [isDraggingCanvas, setIsDraggingCanvas] = useState(false);
  const [isDraggingNode, setIsDraggingNode] = useState<string | null>(null);
  const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const dragDistanceRef = useRef(0);
  const containerRef = useRef<HTMLDivElement>(null);

  // Persistence
  useEffect(() => {
    localStorage.setItem('aero_features_nodes_v2', JSON.stringify(nodes));
  }, [nodes]);
  useEffect(() => {
    localStorage.setItem('aero_features_edges_v2', JSON.stringify(edges));
  }, [edges]);

  // Handle Incoming Prompts
  useEffect(() => {
    if (pendingPrompt) {
      handleGenerate(pendingPrompt);
      onClearPrompt();
    }
  }, [pendingPrompt]);

  const saveToHistory = useCallback((newNodes: Node[], newEdges: Edge[]) => {
    const currentState = { nodes: newNodes, edges: newEdges };
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(currentState);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [history, historyIndex]);

  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      const prevState = history[historyIndex - 1];
      setNodes(prevState.nodes);
      setEdges(prevState.edges);
      setHistoryIndex(prev => prev - 1);
    }
  }, [history, historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      const nextState = history[historyIndex + 1];
      setNodes(nextState.nodes);
      setEdges(nextState.edges);
      setHistoryIndex(prev => prev + 1);
    }
  }, [history, historyIndex]);

  // Clear Canvas
  const handleClearCanvas = useCallback(() => {
    if (confirm("Are you sure you want to clear the entire canvas? This cannot be undone easily (unless you use undo).")) {
      setNodes([]);
      setEdges([]);
      saveToHistory([], []);
      onLog("Canvas cleared.");
    }
  }, [onLog, saveToHistory]);

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.ctrlKey || e.metaKey) {
      const zoomFactor = -e.deltaY * 0.001;
      const newZoom = Math.max(0.2, Math.min(3, viewport.zoom + zoomFactor));
      setViewport(prev => ({ ...prev, zoom: newZoom }));
    } else {
      const dx = e.shiftKey ? e.deltaY : e.deltaX;
      const dy = e.shiftKey ? e.deltaX : e.deltaY;
      setViewport(prev => ({ ...prev, x: prev.x - dx, y: prev.y - dy }));
    }
  };

  const handleGenerate = async (userPrompt: string) => {
    onLog(`Architecting pipeline for: "${userPrompt}"...`);
    onProgress(10);

    try {
      // Call the API layer instead of direct service
      const plan: PipelineSchema | null = await fetchPipelinePlan(userPrompt, nodes);
      
      if (!plan || !plan.nodes) {
        onLog(`Failed to generate a valid plan. Try being more specific.`);
        onProgress(0);
        return;
      }

      onLog(`Plan accepted. Identified ${plan.nodes.length} new logical units.`);
      onProgress(30);
      
      // Animation Loop (Client-side visual effect)
      const newNodes: Node[] = [...nodes];
      const newEdges: Edge[] = [...edges];
      const stepsTotal = plan.nodes.length;

      for (let i = 0; i < stepsTotal; i++) {
        const node = plan.nodes[i];
        const progressPercent = 30 + Math.floor(((i + 1) / stepsTotal) * 70);
        onProgress(progressPercent);
        
        await new Promise(r => setTimeout(r, 600)); 
        
        // Prevent duplicate IDs
        if (newNodes.some(n => n.id === node.id)) {
           continue; 
        }

        newNodes.push(node);
        setNodes([...newNodes]);
        onLog(`Deployed node: [${node.type.toUpperCase()}] ${node.label}`);
      }

      // Add Edges
      if (plan.edges) {
         plan.edges.forEach(e => {
            if (!newEdges.some(ex => ex.id === e.id)) {
               newEdges.push(e);
            }
         });
         setEdges([...newEdges]);
      }
      
      saveToHistory(newNodes, newEdges);
      onLog(`Pipeline construction complete.`);
      onProgress(100);
      setTimeout(() => onProgress(0), 2000); 

    } catch (e) {
      onLog(`Critical Error: ${e}`);
      onProgress(0);
    }
  };

  const getPath = (source: Node, target: Node) => {
    const NODE_WIDTH = 220;
    const ANCHOR_OFFSET_Y = 24; 
    const startX = source.position.x + NODE_WIDTH; 
    const startY = source.position.y + ANCHOR_OFFSET_Y; 
    const endX = target.position.x;
    const endY = target.position.y + ANCHOR_OFFSET_Y;
    const dist = Math.abs(endX - startX);
    const controlOffset = Math.max(dist * 0.5, 50);
    const cp1X = startX + controlOffset;
    const cp1Y = startY;
    const cp2X = endX - controlOffset;
    const cp2Y = endY;
    return `M ${startX} ${startY} C ${cp1X} ${cp1Y}, ${cp2X} ${cp2Y}, ${endX} ${endY}`;
  };

  // Section VIII.B: Config Display Rules
  const renderConfigSummary = (node: Node) => {
    const c = node.config as any;
    // Primary Display based on spec
    switch(node.type) {
      case 'source': 
        return <div className="font-mono text-[10px]">{c.source_name} • {c.format}</div>;
      case 'cleaning': 
        return <div className="font-mono text-[10px]">{c.operation} • {c.strategy || 'N/A'}</div>;
      case 'transform': 
        return <div className="font-mono text-[10px]">{c.operation} → {c.output_column}</div>;
      case 'temporal': 
        return <div className="font-mono text-[10px]">{c.operation} ({c.window})</div>;
      case 'aggregation': 
        return <div className="font-mono text-[10px]">{c.operation} by [{c.group_by?.join(',')}]</div>;
      case 'model': 
        return <div className="font-mono text-[10px]">{c.model_type}</div>;
      case 'output': 
        return <div className="font-mono text-[10px]">{c.output_name} • {c.format}</div>;
      default: 
        return <div className="font-mono text-[10px]">Configured</div>;
    }
  };

  const renderSecondaryConfig = (node: Node) => {
    const c = node.config as any;
    // Secondary Display for Hover
    switch(node.type) {
      case 'source': 
        return (
          <>
            <div>Refresh: {c.refresh_rate}</div>
            <div>Cols: {c.columns?.length || 0}</div>
          </>
        );
      case 'cleaning': 
        return (
          <>
            <div>Threshold: {c.threshold ?? 'N/A'}</div>
            <div>Targets: {c.columns?.join(', ')}</div>
          </>
        );
      case 'transform': 
        return (
          <>
             {c.params && Object.entries(c.params).map(([k, v]) => (
                <div key={k}>{k}: {String(v)}</div>
             ))}
          </>
        );
      case 'temporal': 
        return (
          <>
            <div>Lag Periods: {c.lag_periods?.join(', ') || 'None'}</div>
            <div>Min Periods: {c.min_periods ?? 'N/A'}</div>
          </>
        );
      case 'aggregation': 
        return (
          <>
            <div>Agg Cols: {c.agg_columns?.join(', ')}</div>
          </>
        );
      case 'model': 
        return (
          <>
             {c.hyperparameters && Object.entries(c.hyperparameters).slice(0, 3).map(([k, v]) => (
                <div key={k}>{k}: {String(v)}</div>
             ))}
          </>
        );
      case 'output': 
        return (
          <>
             <div>Cols: {c.columns?.length || 'All'}</div>
          </>
        );
      default: return null;
    }
  };

  return (
    <div className="flex h-full w-full relative overflow-hidden bg-background select-none">
      
      <div 
        ref={containerRef}
        className="absolute inset-0 cursor-grab active:cursor-grabbing z-0"
        onMouseDown={(e) => {
           if ((e.target as HTMLElement).closest('.node-element')) return;
           setIsDraggingCanvas(true);
           setLastMousePos({ x: e.clientX, y: e.clientY });
        }}
        onMouseMove={(e) => {
          const dx = e.clientX - lastMousePos.x;
          const dy = e.clientY - lastMousePos.y;
          const scaledDx = dx / viewport.zoom;
          const scaledDy = dy / viewport.zoom;

          if (isDraggingNode) {
            dragDistanceRef.current += Math.abs(dx) + Math.abs(dy);
            setNodes(prev => prev.map(n => 
              n.id === isDraggingNode ? { ...n, position: { x: n.position.x + scaledDx, y: n.position.y + scaledDy } } : n
            ));
          } else if (isDraggingCanvas) {
            setViewport(prev => ({ ...prev, x: prev.x + dx, y: prev.y + dy }));
          }
          setLastMousePos({ x: e.clientX, y: e.clientY });
        }}
        onMouseUp={() => {
           if (isDraggingNode) saveToHistory(nodes, edges);
           setIsDraggingCanvas(false);
           setIsDraggingNode(null);
        }}
        onMouseLeave={() => { setIsDraggingCanvas(false); setIsDraggingNode(null); }}
        onWheel={handleWheel}
      >
        {/* Grid */}
        <div 
          className="absolute inset-0 pointer-events-none opacity-[0.15] dark:opacity-[0.2]"
          style={{
            backgroundImage: 'radial-gradient(currentColor 1px, transparent 1px)',
            backgroundSize: `${20 * viewport.zoom}px ${20 * viewport.zoom}px`,
            backgroundPosition: `${viewport.x}px ${viewport.y}px`
          }}
        />

        {/* Transform Container */}
        <div 
          style={{ 
            transform: `translate(${viewport.x}px, ${viewport.y}px) scale(${viewport.zoom})`,
            transformOrigin: '0 0',
            width: '100%',
            height: '100%'
          }}
        >
          {/* Edges */}
          <svg className="absolute top-0 left-0 overflow-visible w-full h-full pointer-events-none z-0">
            {edges.map(edge => {
              const sourceNode = nodes.find(n => n.id === edge.source);
              const targetNode = nodes.find(n => n.id === edge.target);
              if (!sourceNode || !targetNode) return null;
              return (
                <g key={edge.id}>
                  <path d={getPath(sourceNode, targetNode)} fill="none" stroke="var(--background)" strokeWidth="4" className="opacity-80" />
                  <path d={getPath(sourceNode, targetNode)} fill="none" stroke="hsl(var(--accent))" strokeWidth="2" className="opacity-70" />
                </g>
              );
            })}
          </svg>

          {/* Nodes */}
          {nodes.map(node => {
             const visual = NODE_VISUALS[node.type] || NODE_VISUALS.source;
             return (
              <div
                key={node.id}
                className={cn(
                  "node-element absolute w-[220px] rounded-lg border-2 shadow-lg bg-card transition-shadow duration-200 group",
                  visual.border, visual.bg,
                  selectedNode?.id === node.id ? "ring-2 ring-primary shadow-2xl" : "hover:shadow-xl",
                  isDraggingNode === node.id ? "cursor-grabbing scale-105 z-50" : "cursor-grab z-10"
                )}
                style={{ left: node.position.x, top: node.position.y }}
                onMouseDown={(e) => {
                  e.stopPropagation();
                  setIsDraggingNode(node.id);
                  setLastMousePos({ x: e.clientX, y: e.clientY });
                  dragDistanceRef.current = 0;
                }}
                onMouseEnter={() => setHoveredNode(node.id)}
                onMouseLeave={() => setHoveredNode(null)}
                onClick={(e) => {
                  e.stopPropagation();
                  if (dragDistanceRef.current < 5) setSelectedNode(node);
                }}
              >
                {/* Anchors */}
                <div className="absolute top-[24px] -left-1.5 w-3 h-3 bg-accent border-2 border-background rounded-full z-20" />
                <div className="absolute top-[24px] -right-1.5 w-3 h-3 bg-accent border-2 border-background rounded-full z-20" />

                <div className="h-10 px-3 border-b border-inherit bg-inherit/20 flex items-center justify-between rounded-t-md">
                  <div className={cn("flex items-center gap-2 font-bold text-xs uppercase tracking-wider", visual.color)}>
                     {visual.icon}
                     {node.type}
                  </div>
                  <Grip size={12} className="opacity-30" />
                </div>

                <div className="p-3 bg-card/95 rounded-b-md">
                  <div className="font-bold text-sm text-foreground truncate mb-1" title={node.label}>{node.label}</div>
                  <div className="text-[10px] text-muted-foreground leading-snug mb-2 line-clamp-2">{node.description}</div>
                  <div className="bg-muted/50 p-1.5 rounded border border-border/50 text-foreground overflow-hidden">
                    {renderConfigSummary(node)}
                  </div>
                </div>

                {/* Hover Details (Secondary Display) */}
                {hoveredNode === node.id && !isDraggingCanvas && !isDraggingNode && !selectedNode && (
                  <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-64 bg-popover text-popover-foreground text-xs rounded-lg shadow-xl p-3 border border-border z-[100] pointer-events-none animate-in fade-in slide-in-from-bottom-2">
                    <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                       {renderSecondaryConfig(node)}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Controls */}
      <div className="absolute bottom-6 left-6 z-20 flex gap-2">
         {/* Zoom */}
         <div className="bg-card/90 backdrop-blur border border-border p-1.5 rounded-lg shadow-lg flex items-center gap-1">
            <button className="p-2 hover:bg-muted rounded text-muted-foreground" onClick={() => setViewport(v => ({...v, zoom: v.zoom + 0.1}))}><ZoomIn size={18}/></button>
            <span className="text-[10px] text-muted-foreground w-8 text-center">{Math.round(viewport.zoom * 100)}%</span>
            <button className="p-2 hover:bg-muted rounded text-muted-foreground" onClick={() => setViewport(v => ({...v, zoom: v.zoom - 0.1}))}><ZoomOut size={18}/></button>
            <div className="w-px h-4 bg-border mx-1" />
            <button className="p-2 hover:bg-muted rounded text-muted-foreground" onClick={() => setViewport({x: 0, y: 0, zoom: 1})}><Maximize size={18}/></button>
            <div className="w-px h-4 bg-border mx-1" />
            <button 
              className={cn("p-2 hover:bg-muted rounded text-muted-foreground", isFullScreen && "text-accent bg-accent/10")} 
              onClick={onToggleFullScreen}
            >
              {isFullScreen ? <Minimize size={18}/> : <Maximize size={18}/>}
            </button>
         </div>

         {/* History & Clear */}
         <div className="bg-card/90 backdrop-blur border border-border p-1.5 rounded-lg shadow-lg flex items-center gap-1">
            <button 
              className={cn("p-2 rounded transition-colors", historyIndex > 0 ? "hover:bg-muted text-foreground" : "text-muted-foreground opacity-50")} 
              onClick={handleUndo}
            >
              <Undo2 size={18}/>
            </button>
            <button 
              className={cn("p-2 rounded transition-colors", historyIndex < history.length - 1 ? "hover:bg-muted text-foreground" : "text-muted-foreground opacity-50")} 
              onClick={handleRedo}
            >
              <Redo2 size={18}/>
            </button>
            <div className="w-px h-4 bg-border mx-1" />
            <button 
              className="p-2 hover:bg-destructive/10 text-destructive rounded transition-colors"
              title="Clear Canvas"
              onClick={handleClearCanvas}
            >
              <Trash2 size={18} />
            </button>
         </div>
      </div>

      {/* Edit Dialog */}
      {selectedNode && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200" onMouseDown={() => setSelectedNode(null)}>
          <div className="bg-card w-full max-w-lg rounded-xl shadow-2xl border border-border overflow-hidden animate-in zoom-in-95 duration-200" onMouseDown={(e) => e.stopPropagation()}>
             <div className="flex items-center justify-between p-4 border-b border-border bg-muted/30">
               <h3 className="font-bold flex items-center gap-2 text-lg">
                 {NODE_VISUALS[selectedNode.type].icon}
                 Edit: <span className="text-accent">{selectedNode.label}</span>
               </h3>
               <button onClick={() => setSelectedNode(null)} className="p-1 hover:bg-destructive/10 hover:text-destructive rounded transition-colors">
                 <X size={20} />
               </button>
             </div>
             
             <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                <div className="grid grid-cols-2 gap-4">
                    {Object.entries(selectedNode.config).map(([key, val]) => (
                      <div key={key}>
                        <label className="text-[10px] font-medium uppercase text-muted-foreground mb-1 block">{key.replace('_', ' ')}</label>
                        <input 
                          type="text" 
                          defaultValue={typeof val === 'object' ? JSON.stringify(val) : String(val)} 
                          className="w-full bg-background border border-input rounded px-3 py-2 text-sm focus:ring-1 focus:ring-accent outline-none" 
                        />
                      </div>
                    ))}
                </div>
                <div>
                   <label className="text-xs font-bold text-muted-foreground uppercase mb-2 block">Description</label>
                   <textarea 
                     className="w-full h-24 bg-background border border-input rounded p-3 text-sm focus:ring-1 focus:ring-accent outline-none resize-none"
                     defaultValue={selectedNode.description}
                   />
                </div>
             </div>

             <div className="p-4 border-t border-border bg-muted/30 flex justify-between items-center">
                <button 
                  onClick={() => {
                     const newNodes = nodes.filter(n => n.id !== selectedNode.id);
                     const newEdges = edges.filter(e => e.source !== selectedNode.id && e.target !== selectedNode.id);
                     setNodes(newNodes);
                     setEdges(newEdges);
                     saveToHistory(newNodes, newEdges);
                     setSelectedNode(null);
                  }}
                  className="text-destructive text-sm flex items-center gap-2 hover:bg-destructive/10 px-3 py-2 rounded transition-colors"
                >
                  <Trash2 size={16} /> Delete Node
                </button>
                <div className="flex gap-2">
                   <button onClick={() => setSelectedNode(null)} className="px-4 py-2 rounded text-sm hover:bg-muted">Cancel</button>
                   <button onClick={() => setSelectedNode(null)} className="px-4 py-2 bg-accent text-accent-foreground rounded text-sm font-medium flex items-center gap-2 shadow-lg shadow-accent/20">
                     <Save size={16} /> Save
                   </button>
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};
